package ylag.paolo.webprg;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class prefServlet
 */
@WebServlet("/pref")
public class prefServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public prefServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// get the inputs of the user
		String backgroundc = request.getParameter("bgclr");
		String fontc = request.getParameter("ftclr");
		String postc = request.getParameter("pstclr");
		
		
		//open a new session
		HttpSession session = request.getSession();
		session.setAttribute("bgclr", backgroundc);
		session.setAttribute("ftclr", fontc);
		session.setAttribute("pstclr", postc);
		
		//add a cookie
		Cookie c = new Cookie("bgclr", backgroundc);
		Cookie c1 = new Cookie("ftclr", fontc);
		Cookie c2 = new Cookie("pstclr", postc);
		
		c.setMaxAge(60*60*24);
		response.addCookie(c);
		c1.setMaxAge(60*60*24);
		response.addCookie(c1);
		c2.setMaxAge(60*60*24);
		response.addCookie(c2);
		
		request.getRequestDispatcher("index.jsp")
		.forward(request, response);
	}

}
