package ylag.paolo.webprg;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class checkerServlet
 */
@WebServlet("/checkerServlet")
public class checkerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public checkerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// check if user has logged in
		
		Cookie[] cookieList = request.getCookies();
		String bgclr = "white";
		String ftclr = "white";
		String pstclr = "white";
		if(cookieList != null)
		{
			for(Cookie c: cookieList)
			{
				if(c.getName().equals("bgclr"))
				{
					bgclr = c.getValue();
				}else if(c.getName().equals("ftclr"))
				{
					ftclr = c.getValue();
				}else if(c.getName().equals("pstclr"))
				{
					pstclr = c.getValue();
				}
			}
		}
		request.getSession().setAttribute("bgclr", bgclr);
		request.getSession().setAttribute("ftclr", ftclr);
		request.getSession().setAttribute("pstclr", pstclr);
		request.getRequestDispatcher("index.jsp").forward(request, response);
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
